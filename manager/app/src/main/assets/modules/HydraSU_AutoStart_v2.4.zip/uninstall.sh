#!/system/bin/sh
rm -f /data/adb/hydra/.silent 2>/dev/null
