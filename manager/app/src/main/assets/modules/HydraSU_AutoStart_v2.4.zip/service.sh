#!/system/bin/sh
MODDIR=${0%/*}
BB=/data/adb/ksu/bin/busybox
SVC=io.hydra.kernel/com.rifsxd.ksunext.ParasiteService
WWW=/data/adb/modules/hydrasu_standalone_console/www

(
    n=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ $n -lt 90 ]; do
        sleep 2; n=$((n+1))
    done
    sleep 10

    # MIUI 冻结豁免
    cmd appops set io.hydra.kernel RUN_ANY_IN_BACKGROUND allow 2>/dev/null
    cmd deviceidle whitelist +io.hydra.kernel 2>/dev/null

    # 协作主循环：每 30 秒仲裁一次端口归属
    while true; do
        LISTEN=$(grep -i ':956E' /proc/net/tcp /proc/net/tcp6 2>/dev/null | grep -ci ' 0A ')
        if [ "$LISTEN" = "0" ]; then
            if [ -n "$(pm path io.hydra.kernel 2>/dev/null)" ]; then
                # 管理器在：静默拉起它的服务（完整功能控制台）
                touch /data/adb/hydra/.silent 2>/dev/null
                am start-service -n "$SVC" >/dev/null 2>&1
            else
                # 管理器已删除：模块 httpd 接管（独立控制台）
                chmod 755 /data/adb/modules/hydrasu_standalone_console/cgi-bin/hydra 2>/dev/null
                [ -d "$WWW" ] && $BB httpd -p 127.0.0.1:38214 -h "$WWW" 2>/dev/null
            fi
        else
            # 端口有人监听：若监听者是模块 httpd 而管理器又装回来了，让位给管理器
            if [ -n "$(pm path io.hydra.kernel 2>/dev/null)" ] && pgrep -f "httpd.*38214" >/dev/null 2>&1; then
                $BB pkill -f "httpd.*38214" 2>/dev/null
                sleep 1
                touch /data/adb/hydra/.silent 2>/dev/null
                am start-service -n "$SVC" >/dev/null 2>&1
            fi
        fi
        sleep 30
    done
) &
