#!/system/bin/sh
/data/adb/ksu/bin/busybox pkill -f "httpd.*38214" 2>/dev/null
