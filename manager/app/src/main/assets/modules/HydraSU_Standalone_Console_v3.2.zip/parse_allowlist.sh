#!/system/bin/sh
# 从内核持久化授权文件（二进制 .allowlist）解析已授权（ROOT）uid 列表
# v2：容忍头部 0/特殊记录 + 按记录读 allow_su 字节（只输出真 ROOT）
BB=/data/adb/ksu/bin/busybox
AL=/data/adb/ksu/.allowlist
TMP=/data/local/tmp/.al_u32
[ -f "$AL" ] || exit 0

$BB od -A n -t u4 -v "$AL" | tr -s ' ' '\n' | grep -v '^$' > "$TMP"
TOTAL=$(wc -l < "$TMP")
[ "$TOTAL" -ge 4 ] || { rm -f "$TMP"; exit 0; }

BEST_N=0; BEST_H=0; BEST_O=17; BEST_S=84
for HDR in 0 1 2 3 4; do
  for OFF in 15 16 17 18 19; do
    for STRIDE in $(seq 80 4 430); do
      OUT=$($BB awk -v total="$TOTAL" -v hdr="$HDR" -v off="$OFF" -v stride="$STRIDE" '
        { v[NR] = $1 }
        END {
          ok = 0; bad = 0; k = hdr;
          while (k + off < total) {
            u = v[k + off + 1];
            if (u >= 10000 && u <= 19999) ok++;
            else bad++;
            k += stride;
          }
          if (ok >= 3 && bad <= 2) print ok;
        }' "$TMP" 2>/dev/null)
      if [ -n "$OUT" ] && [ "$OUT" -gt "$BEST_N" ]; then
        BEST_N=$OUT; BEST_H=$HDR; BEST_O=$OFF; BEST_S=$STRIDE
      fi
    done
  done
done

if [ "$BEST_N" -gt 0 ]; then
  # 按最优参数逐记录提取 uid + allow_su 字节（只输出 allow_su != 0 的）
  IDX=0
  K=$BEST_H
  while [ $((K + BEST_O)) -lt $TOTAL ]; do
    U=$(sed -n "$((K + BEST_O + 1))p" "$TMP" 2>/dev/null)
    case "$U" in ''|*[!0-9]*) K=$((K + BEST_S)); continue;; esac
    BYTEOFF=$((K * 4 + BEST_O * 4 + 4))
    SU=$($BB dd if="$AL" bs=1 skip="$BYTEOFF" count=1 2>/dev/null | $BB od -A n -t u1 | tr -s ' ' '\n' | grep -v '^$' | head -n1)
    if [ -n "$SU" ] && [ "$SU" != "0" ] && [ "$U" -ge 10000 ] && [ "$U" -le 19999 ]; then
      echo "$U"
    fi
    IDX=$((IDX + 1))
    K=$((K + BEST_S))
  done
fi
rm -f "$TMP"
exit 0
