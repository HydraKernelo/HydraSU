#!/system/bin/sh
# 生成应用列表 v4：
#  - 只含第三方应用（pm -3，系统应用从列表排除）
#  - granted = console 授权文件 ∪ 内核持久化授权（.allowlist 解析）
MODDIR=${0%/*}
A=/data/adb/hydra/allow_uids
T=/data/adb/hydra/apps.json
TMP=/data/local/tmp/.hydra_apps_gen
KGR=/data/local/tmp/.hydra_kgrant

sh "$MODDIR/parse_allowlist.sh" > "$KGR" 2>/dev/null

: > "$TMP"

/system/bin/pm list packages -U -3 2>/dev/null | while IFS= read -r line; do
    pkg=${line#package:}
    pkg=${pkg%% *}
    uid=${line##*uid:}
    case "$uid" in ''|*[!0-9]*) continue;; esac
    g="false"
    grep -q "^$uid\$" "$A" 2>/dev/null && g="true"
    grep -q "^$uid\$" "$KGR" 2>/dev/null && g="true"
    printf '{"pkg":"%s","uid":%s,"granted":%s,"configured":false,"system":false,"userId":%s},\n' \
        "$pkg" "$uid" "$g" $((uid / 100000)) >> "$TMP"
done

O=$(cat "$TMP" 2>/dev/null)
O=${O%,}
printf '{"list":[%s]}' "$O" > "$T"
rm -f "$TMP" "$KGR"
exit 0
