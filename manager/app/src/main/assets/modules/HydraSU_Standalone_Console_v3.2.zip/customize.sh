SKIPUNZIP=0
ui_print "- HydraSU Standalone Console v1.7"
chmod 755 /data/adb/modules/hydrasu_standalone_console/service.sh 2>/dev/null
chmod 755 /data/adb/modules/hydrasu_standalone_console/www/cgi-bin/hydra 2>/dev/null
ui_print "- CGI 权限已设置"
