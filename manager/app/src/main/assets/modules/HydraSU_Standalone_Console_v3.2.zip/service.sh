#!/system/bin/sh
MODDIR=${0%/*}
PATH=/system/bin:/system/xbin:/vendor/bin:$PATH
export PATH
BB="$MODDIR/busybox"

(
    n=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ $n -lt 90 ]; do
        sleep 2; n=$((n+1))
    done
    sleep 3

    # 自愈：CGI 执行权限
    chmod 755 /data/adb/modules/hydrasu_standalone_console/www/cgi-bin/hydra 2>/dev/null
    chmod 755 /data/adb/modules/hydrasu_standalone_console/gen_apps.sh 2>/dev/null
    chmod 755 /data/adb/modules/hydrasu_standalone_console/parse_allowlist.sh 2>/dev/null

    # 生成一次应用列表（root 服务上下文，pm 可用）
    sh /data/adb/modules/hydrasu_standalone_console/gen_apps.sh >/dev/null 2>&1

    # 保活主循环：httpd 掉了就拉起（每 30 秒），应用列表每 5 分钟刷新
    t=0
    while true; do
        if ! grep -qi ':956E' /proc/net/tcp /proc/net/tcp6 2>/dev/null; then
            $BB pkill -f "httpd.*38214" 2>/dev/null
            $BB httpd -p 127.0.0.1:38214 -h "$MODDIR/www" 2>/dev/null
        fi
        t=$((t + 1))
        if [ $t -ge 10 ]; then
            t=0
            sh /data/adb/modules/hydrasu_standalone_console/gen_apps.sh >/dev/null 2>&1
        fi
        sleep 30
    done
) &
